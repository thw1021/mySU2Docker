#if !defined(PETSCCUBLAS_H)
#define PETSCCUBLAS_H

#warning "petsccublas.h is deprecated, use petscdevice.h instead"

#include <petscdevice.h>

#endif /* PETSCCUBLAS_H */
