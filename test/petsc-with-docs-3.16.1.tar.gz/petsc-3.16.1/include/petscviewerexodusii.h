
#if !defined(PETSCVIEWEREXODUSII_H)
#define PETSCVIEWEREXODUSII_H

#include <petscviewer.h>

#if defined(PETSC_HAVE_EXODUSII)
#include <exodusII.h>

#endif  /* defined(PETSC_HAVE_EXODUSII) */
#endif
